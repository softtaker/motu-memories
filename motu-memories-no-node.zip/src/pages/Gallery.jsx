import WallpaperViewer from '../components/WallpaperViewer';

function Gallery() {
  return (
    <section className="page-block">
      <p className="section-label">Gallery</p>
      <WallpaperViewer
        title="Motu & Love"
        caption="A warm reminder of the soft memories we keep close."
      />
    </section>
  );
}

export default Gallery;
