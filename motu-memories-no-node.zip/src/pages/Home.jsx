import MemoryCard from '../components/MemoryCard';
import { memories } from '../data/memories';

function Home() {
  return (
    <section className="page-block">
      <p className="section-label">Sweet moments</p>
      <div className="memory-list">
        {memories.slice(0, 2).map((item) => (
          <MemoryCard key={item.id} item={item} />
        ))}
      </div>
    </section>
  );
}

export default Home;
