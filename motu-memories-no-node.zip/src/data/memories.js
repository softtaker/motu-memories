const memories = [
  {
    id: 1,
    date: "19 February",
    title: "Me & Motu Commit ❤️",
    description: "The beginning of our beautiful journey.",
    image: "/images/timeline.png",
  },
  {
    id: 2,
    date: "22 March",
    title: "Motu Nonu 🥰",
    description: "One of the cutest memories together.",
    image: "/images/timeline.png",
  },
  {
    id: 3,
    date: "25 August",
    title: "Motu's Birthday 🎂",
    description: "A day filled with happiness, love and beautiful memories.",
    image: "/images/timeline.png",
  },
];

export default memories;