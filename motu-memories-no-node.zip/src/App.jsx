import Header from "./components/Header";
import Hero from "./components/Hero";
import Timeline from "./components/Timeline";
import FloatingHearts from "./components/FloatingHearts";

export default function App() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-pink-100 via-rose-50 to-pink-200 relative overflow-hidden">

      <FloatingHearts />

      <div className="relative z-10">

        <Header />

        <Hero />

        <Timeline />

      </div>

    </div>
  );
}