import { motion } from "framer-motion";
import { FaHeart } from "react-icons/fa";

export default function Hero() {
  return (
    <section className="max-w-6xl mx-auto px-6 mb-20">

      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 40 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        transition={{ duration: 1 }}
        className="bg-white/80 backdrop-blur-lg rounded-[35px] shadow-2xl overflow-hidden"
      >

        <img
          src="/images/hero.jpg"
          alt="Hero"
          className="w-full h-[520px] object-cover"
        />

        <div className="p-10 text-center">

          <FaHeart className="mx-auto text-5xl text-pink-600 animate-pulse" />

          <h2 className="text-5xl font-bold text-pink-700 mt-6">

            Good Morning Motu ❤️

          </h2>

          <p className="mt-5 text-lg text-gray-600 leading-8 max-w-3xl mx-auto">

            Every day spent with you becomes another beautiful memory that
            I will treasure forever.

          </p>

          <button
            className="
              mt-8
              px-10
              py-4
              rounded-full
              bg-pink-600
              hover:bg-pink-700
              text-white
              text-lg
              font-semibold
              shadow-xl
              transition-all
              duration-300
              hover:scale-105
            "
          >
            Begin Our Journey ❤️
          </button>

        </div>

      </motion.div>

    </section>
  );
}