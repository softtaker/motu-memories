import { motion } from "framer-motion";
import memories from "../data/memories";

export default function Timeline() {
  return (
    <section className="max-w-6xl mx-auto px-6 pb-20">

      <motion.h2
        initial={{ opacity: 0 }}
        whileInView={{ opacity: 1 }}
        className="text-4xl font-bold text-center text-pink-700 mb-10"
      >
        Our Journey ❤️
      </motion.h2>

      <div className="bg-white rounded-3xl shadow-2xl overflow-hidden mb-12">

        <img
          src="/images/timeline.png"
          alt="Timeline"
          className="w-full"
        />

      </div>

      <div className="grid md:grid-cols-3 gap-8">

        {memories.map((memory) => (

          <motion.div
            key={memory.id}
            whileHover={{
              y: -10,
              scale: 1.03,
            }}
            className="bg-white rounded-3xl shadow-xl p-6"
          >

            <h3 className="text-pink-600 text-xl font-bold">

              {memory.date}

            </h3>

            <h2 className="mt-3 text-2xl font-bold">

              {memory.title}

            </h2>

            <p className="mt-3 text-gray-600">

              {memory.description}

            </p>

          </motion.div>

        ))}

      </div>

    </section>
  );
}