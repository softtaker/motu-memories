function BottomNav({ activePage, onNavigate }) {
  const links = [
    { id: 'home', label: 'Home' },
    { id: 'memories', label: 'Memories' },
    { id: 'gallery', label: 'Gallery' },
  ];

  return (
    <nav className="bottom-nav" aria-label="Main navigation">
      {links.map((link) => (
        <button
          key={link.id}
          className={activePage === link.id ? 'nav-btn active' : 'nav-btn'}
          onClick={() => onNavigate(link.id)}
          type="button"
        >
          {link.label}
        </button>
      ))}
    </nav>
  );
}

export default BottomNav;
