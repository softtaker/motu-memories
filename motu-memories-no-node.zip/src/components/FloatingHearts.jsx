import { FaHeart } from "react-icons/fa";

export default function FloatingHearts() {
  return (
    <>
      {[...Array(20)].map((_, index) => (
        <FaHeart
          key={index}
          className="floating-heart"
          style={{
            left: `${Math.random() * 100}%`,
            animationDelay: `${Math.random() * 12}s`,
            animationDuration: `${10 + Math.random() * 10}s`,
            fontSize: `${12 + Math.random() * 22}px`,
          }}
        />
      ))}
    </>
  );
}